import dataset_handling_module.db_to_dataset as dataset

# Data Preprocessing

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
def import_dataset():

    global X,y
    dataset = pd.read_csv('C:/xampp5/htdocs/be_project/dataset/final_dataset.csv')
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, 9].values
    return

def encode_categorical_data():

    global X,y

    # Encoding categorical data
    # Encoding the Independent Variable
    #OneHotEncoder is giving an error could not convert string to float in some cases
    from sklearn.preprocessing import LabelEncoder, OneHotEncoder
    labelencoder_X = LabelEncoder()
    X[:, 2] = labelencoder_X.fit_transform(X[:, 2])
    X[:, 7] = labelencoder_X.fit_transform(X[:, 7])
    return
    
def fill_missing_data():

    global X,y
    
    # Taking care of missing data
    from sklearn.preprocessing import Imputer
    imputer = Imputer(missing_values = 'NaN', strategy = 'mean', axis = 0)
    imputer = imputer.fit(X[:, 3:6])
    X[:, 3:6] = imputer.transform(X[:, 3:6])
    return
    
def split_train_test():
    
    global X_train, X_test, y_train, y_test
    global X,y
    
    # Splitting the dataset into the Training set and Test set
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)
    return

def feature_scale():
    
    # Feature Scaling
    global X_train, X_test, y_train, y_test
    global X,y
    
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)
    return
    
def main():
    # operations for appending new user info into the existing dataset
    dataset.get_user_info()
    dataset.write_info_to_dataset()
    dataset.append_to_train_dataset()
    
    # preprocessor calls
    import_dataset()
    encode_categorical_data()
    fill_missing_data()
    split_train_test()
    feature_scale()
    
if __name__== "__main__":
    main()
    

    
    

    




