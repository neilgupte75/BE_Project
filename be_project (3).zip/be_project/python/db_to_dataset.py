import MySQLdb
import csv

db = MySQLdb.connect  ("localhost","root","","lung_cancer")
query = "SELECT * FROM user_info"
cancer_attributes = []
cancer_attribute_value = []

cursor = db.cursor()
cursor.execute(query)
data = cursor.fetchone()
cancer_attributes = [i[0] for i in cursor.description]

for row in data:
    cancer_attribute_value.append(row);
    
myData = [cancer_attributes,cancer_attribute_value]
 
myFile = open('../dataset/test.csv', 'a')

with myFile:
    writer = csv.writer(myFile)
    writer.writerows(myData)
     
print("Writing complete")
    
db.close()
