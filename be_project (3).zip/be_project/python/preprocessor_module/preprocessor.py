# Data Preprocessing

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('../dataset/final_dataset.csv')
X = dataset.iloc[:, :].values

def encode_categorical_data():

    global X

    # Encoding categorical data
    # Encoding the Independent Variable
    #OneHotEncoder is giving an error could not convert string to float in some cases
    from sklearn.preprocessing import LabelEncoder, OneHotEncoder
    labelencoder_X = LabelEncoder()
    X[:, 2] = labelencoder_X.fit_transform(X[:, 2])
    X[:, 7] = labelencoder_X.fit_transform(X[:, 7])
    
def fill_missing_data():

    global X
    
    # Taking care of missing data
    #The last row isnt showing any change fix this issue
    from sklearn.preprocessing import Imputer
    imputer = Imputer(missing_values = 'NaN', strategy = 'mean', axis = 0)
    imputer = imputer.fit(X[:, 3:6])
    X[:, 3:6] = imputer.transform(X[:, 3:6])

    
