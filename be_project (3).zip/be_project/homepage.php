<?php 
  session_start();
  require 'db/questionnaire.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Prediction of Lung Cancer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap-3.3.7/bootstrap-3.3.7/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/font-awesome-4.6.3/css/font-awesome.css">
  <link rel="stylesheet" href="css/main.css">
  <link href="css/font-families/montserrat.css" rel="stylesheet" type="text/css">
  <link href="css/font-families/lato.css" rel="stylesheet" type="text/css">
  <script src="javascript/jquery.min.js"></script>
  <script src="javascript/main.js"></script>
  <script src="css/bootstrap-3.3.7/bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>
</head>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#form">FORM</a></li>
        <li><a href="#contact">CONTACT</a></li>
        <li><a href="index.php">LOGOUT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center">
  <h1>Welcome <?php echo $_SESSION['username']; ?></h1> 
</div>

<div id="form" class="container-fluid">
  <center><h3>Provide your details</h3></center>
  <form class="form-horizontal" action="homepage.php" method="post">
    <div class = "form-group">
      <label class="control-label">Cigarette years </label><br>
      <input type="number" class="form-control" name="cigarette"/> 
      <label class="control-label">Occupation </label><br>
      <input type="text" class="form-control" name="occupation"/>   
      <label class="control-label">Height </label><br>
      <input type="number" class="form-control" name="height"/>
      <label class="control-label">Weight</label><br>
      <input type="number" class="form-control" name="weight"/>  
      <label class="control-label">Age</label><br>
      <input type="number" class="form-control" name="age"/>
      <label class="control-label">Date of Birth</label><br>
      <input type="date" class="form-control" name="birth" id="DOB"/><br>
      <label class="control-label" style="margin-right: 5px">Sex </label>
      <input type="radio" value="Female" name="sex" style="margin-right: 5px"/>Female 
      <input type="radio" value="male" name="sex" style="margin-right: 5px"/>Male<br><br>
      <button type="submit" class="btn btn-success" id="submit_btn" name="submit">Submit</button><br>
    </div>     
  </form>
</div>

<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center">CONTACT</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Contact us and we'll get back to you within 24 hours.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Chicago, US</p>
      <p><span class="glyphicon glyphicon-phone"></span> +00 1515151515</p>
      <p><span class="glyphicon glyphicon-envelope"></span> myemail@something.com</p>
    </div>
    <div class="col-sm-7 slideanim">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit">Send</button>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <h3>Created by</h3>
  <br>
  <p>Sumit Khopkar</p>
  <p>Neil Gupte</p>
  <p>Purva Kulkarni</p>
  <p>Anvay Sonpimple</p>
</footer>

</body>
</html>
