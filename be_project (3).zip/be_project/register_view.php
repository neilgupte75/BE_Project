<?php 
	require 'db/register.php';
?>
<!DOCTYPE html>
<html>
<head>

<title>Registration Page </title>
<link rel="stylesheet" href="css/style.css">

</head>

<body style="background-color:#2c3e50">

	<div  id="main-wrapper"> 
		<center><h2>Registration Page </h2>
			<img src="imgs/dochealth.jpg" class="doc"/>
		
	
	
		<form class="myform" action="register_view.php" method="post">
		<label>Username:</label><br>
		<input name="username" type="text" class="inputvalues" placeholder="Type Your Username" required/><br>
		<label>Password:</label><br>
		<input name="password" type="password" class="inputvalues" placeholder="Type Your password" required/><br>
		<label>Confirm Password:</label><br>
		<input name="cpassword" type="password" class="inputvalues" placeholder="Confirm your password" required/><br>
		<input name="submit_btn" type="submit" id="signup_btn" value="Sign Up"/><br>
		 <a href="index.php" />  <input type="button" id="back_btn" value="Back"/>
		</form>
		</center>
		
		
	</div>
</body>

</html>