<?php

$servername = "localhost";
$username = "root";
$password="";


// Create connection
$conn = mysql_connect($servername, $username,$password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysql_connect_error());
}

?>
<?php
$conn = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("lung_cancer", $conn); // Selecting Database from Server
if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$cigarette = $_POST['cigarette'];
$occupation = $_POST['occupation'];
$height = $_POST['height'];
$weight = $_POST['weight'];
$age = $_POST['age'];
$birth = $_POST['birth'];
$sex = $_POST['sex'];
$user_id = $_SESSION['user_id'];

if($age !=''|| $birth !=''){
//Insert Query of SQL
$query = mysql_query("insert into user_info(cigarette_years, occupation, height, weight,age,date_of_birth,sex,user_id) values ('$cigarette', '$occupation', '$height', '$weight','$age','$birth','$sex','$user_id')");
echo '<script type="text/javascript"> alert("Successfully entered details, please wait for sometime for our model to evaluate your percentage of lung cancer risk. You will receive a mail with a pdf file attached to it which would contain information regarding the result that our model has evaluated")</script>';
}

else{
	echo '<script type="text/javascript"> alert("Some problem has occured, please try again")</script>';
}
}

?>