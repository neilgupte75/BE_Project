<?php

if(isset($_POST['submit'])){

    if(!empty($_POST['age']) && isset($_POST['sex']) && isset($_POST['education']) && isset($_POST['marital']) && isset($_POST['occupation']) && isset($_POST['race']) && isset($_POST['cig-stat']) && !empty($_POST['cig-stop']) && !empty($_POST['cig-years']) && isset($_POST['cigar']) && isset($_POST['cig-pd']) && isset($_POST['filtered']) && !empty($_POST['pack-years']) && isset($_POST['pipe']) && isset($_POST['smoked-f']) && !empty($_POST['smoked-af']) && isset($_POST['smoked-r']) && !empty($_POST['smoked-s']) && isset($_POST['sisters']) && isset($_POST['brothers']) && !empty($_POST['bmi']) && !empty($_POST['weight']) && !empty($_POST['height']))
    {
    	$data = array ( $_POST['age'],$_POST['sex'], $_POST['education'],$_POST['marital'], $_POST['occupation'],$_POST['race'], $_POST['cig-stat'], $_POST['cig-stop'], $_POST['cig-years'], $_POST['cigar'], $_POST['cig-pd'], $_POST['filtered'], $_POST['pack-years'], $_POST['pipe'], $_POST['smoked-f'], $_POST['smoked-af'], $_POST['smoked-r'], $_POST['smoked-s'], $_POST['sisters'], $_POST['brothers'], $_POST['bmi'], $_POST['weight'], $_POST['height']);

        $email_data = array($_SESSION['username']);

    	$fp = fopen('dataset/temp.csv', 'w');

    	fputcsv($fp, $data);

    	fclose($fp);

        $fp1 = fopen('dataset/emails.csv', 'w');

        fputcsv($fp1, $email_data);

        fclose($fp1);

    }
    else
    {
    	echo '<script type="text/javascript"> alert("Fill all the fields")</script>';
    	unset($_POST['submit']);
    }
    
}

?>