$(document).ready(function(){
	
	$("#get-pred-result").click(function(){
		
	});
})