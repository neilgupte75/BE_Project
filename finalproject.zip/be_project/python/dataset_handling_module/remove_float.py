import pandas as pd
import csv

dataset = pd.read_csv('C:/xampp5/htdocs/be_project/dataset/temp_test2.csv')

dataset_attribute_list = []
dataset_attribute_values = []

#print(int(dataset['bmi_curr'][0]))

for record in range(len(dataset)):

    dataset['bmi_curr'][record] = int(dataset['bmi_curr'][record])
    dataset['cig_stop'][record] = int(dataset['cig_stop'][record])
    dataset['pack_years'][record] = int(dataset['pack_years'][record])
    print("written")
    
print([dataset])

dataset.to_csv('C:/xampp5/htdocs/be_project/dataset/temp_test2.csv', index=False)

    
"""with open('C:/xampp5/htdocs/be_project/dataset/temp_test2.csv', 'a', newline = '') as f:
    
    writer = csv.writer(f)
    writer.writerows(dataset_attribute_values)"""

